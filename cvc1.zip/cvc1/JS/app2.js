const items = [
    {
        nome: 'Pacote Cancun',
        valor: 1500.25,
        imagem: 'IMG/cancun.jpg',
        link : 'pp-cancun.html',
        quantidade : 0
    },

    {
        nome: 'Pacote Grécia',
        valor: 1760.55,
        imagem: 'IMG/grecia.jpg',
        link : 'pp-grecia.html',
        quantidade : 0
    },

    {
        nome: 'Pacote Egito',
        valor: 1260.99,
        imagem: 'IMG/egito.jpg',
        link : 'pp-egito.html',
        quantidade : 0
    },

    {
        nome: 'Pacote Paris',
        valor: 3510.75,
        imagem: 'IMG/paris.jpg',
        link : 'pp-paris.html',
        quantidade : 0
    },

    {
        nome: 'Pacote Maldivas',
        valor: 3780.99,
        imagem: 'IMG/maldivas.jpg',
        link : 'pp-maldivas.html',
        quantidade : 0
    },

    {
        nome: 'Pacote Roma',
        valor: 2450.55,
        imagem: 'IMG/roma.jpg',
        link : 'pp-roma.html',
        quantidade : 0
    }
]

precoProduto = () => {
    var containerProdutos = document.getElementById('preco');
    var cuscuz = document.getElementById('abc').innerText;
    items.map((val) => {
        if(cuscuz == val.nome[0]){
            containerProdutos.innerHTML += `
            <p class="lead">
                <font style="vertical-align: inherit;">
                    <font style="vertical-align: inherit;">R$ `+val.valor+`</font>
                </font>
            </p>
        `;
    }
    })
}

precoProduto();