const items = [
    {
        id: 0,
        nome: 'Pacote Cancun',
        valor: 1000.99,
        imagem: 'IMG/cancun.jpg',
        link: 'pp-cancun.html',
        quantidade: 0
    },

    {
        id: 1,
        nome: 'Pacote Grécia',
        valor: 1500.99,
        imagem: 'IMG/grecia.jpg',
        link: 'pp-grecia.html',
        quantidade: 0
    },

    {
        id: 2,
        nome: 'Pacote Egito',
        valor: 2000.99,
        imagem: 'IMG/egito.jpg',
        link: 'pp-egito.html',
        quantidade: 0
    },

    {
        id: 3,
        nome: 'Pacote Paris',
        valor: 2500.99,
        imagem: 'IMG/paris.jpg',
        link: 'pp-paris.html',
        quantidade: 0
    },

    {
        id: 4,
        nome: 'Pacote Maldivas',
        valor: 3000.99,
        imagem: 'IMG/maldivas.jpg',
        link: 'pp-maldivas.html',
        quantidade: 0
    },

    {
        id: 5,
        nome: 'Pacote Roma',
        valor: 3500.99,
        imagem: 'IMG/roma.jpg',
        link: 'pp-roma.html',
        quantidade: 0
    }
]

inicializarLoja = () => {
    var containerProdutos = document.getElementById('produtos');
    items.map((val) => {
        containerProdutos.innerHTML += `
            <div class="card m-3" style="width: 18rem;">
            <img src="`+ val.imagem + `" class="card-img-top" alt="` + val.nome + `">
            <div class="card-body">
                <h5 class="card-title">`+ val.nome + `</h5>
                <p class="card-text">R$ `+ val.valor + `</p>
                <a href="`+ val.link + `" class="btn btn-outline-primary">Detalhes</a>
                <a href="#nada" key="`+ val.id +`" class="btn btn-primary mt-2 add-cart">Adicionar ao Carrinho</a>
            </div>
        </div>
        `;
    })
}

inicializarLoja();

atualizarCarrinho = () => {
    var containerCarrinho = document.getElementById('carrinho');
    containerCarrinho.innerHTML = "";
    items.map((val) => {
        if (val.quantidade > 0) {
        var totalProdutos = val.quantidade * val.valor;
        containerCarrinho.innerHTML += `
                <p class="lead">`+ val.nome + ` | Quantidade: `+val.quantidade+` | Total Produto: `+totalProdutos+ `</p>
                <hr>
        `;
        }
    })
}

motrarTotal = () => {
    var containerCompra = document.getElementById('total')
    if (1<10){
        containerCompra.innerHTML += `
        <p class="lead">Total da Compra: `+ val.nome + ` | Quantidade: `+val.quantidade+` | Total Produto: `+totalProdutos+ `</p>
        `;
    }
}

var links = document.getElementsByClassName('add-cart');

for (var i = 0; i < links.length; i++) {
    links[i].addEventListener("click", function () {
        let key = this.getAttribute('key');
        items[key].quantidade++;
        atualizarCarrinho();
        mostrarTotal();
        return false;
    })
}
