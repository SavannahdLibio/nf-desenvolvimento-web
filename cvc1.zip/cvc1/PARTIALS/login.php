<?php 
session_start();
include('db.php');

if(empty($_POST['login']) || empty($_POST['password'])) {
    header('Location : ../login.html');
    exit();
}

$email = mysqli_real_escape_string($conexao, $_POST['login']);
$senha = mysqli_real_escape_string($conexao, $_POST['password']);

$query = "select nome from clientes where email = '{$email}' and senha = '{$senha}'";

$result = mysqli_query($conexao, $query);

$row = mysqli_num_rows($result);

echo($row);

if ($row == 1){
    $_SESSION['login'] = $email;
    header('Location: ../painel.php');
    exit();
}else{
    header('Location: ../login.html');
    exit();
}
?>