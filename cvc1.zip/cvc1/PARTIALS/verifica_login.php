<?php
session_reset();
if(!$_SESSION['login']){
    header('Location: ../index.html');
}
?>