<?php 
include('db.php');

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];
$telefone = $_POST['telefone'];
$genero = $_POST['genero'];
$dataNasc = $_POST['data_nascimento'];
$cidade = $_POST['cidade'];
$estado = $_POST['estado'];
$endereco = $_POST['endereco'];

$sql = "INSERT INTO clientes VALUES ('$nome', '$email', '$senha', '$telefone', '$genero', '$dataNasc', '$cidade', '$estado', '$endereco')";

if(mysqli_query($conexao, $sql)){
    echo "Usuário cadastrado com sucesso!";
    header('Location: ../index.html');
}
else{
    echo "Erro ".mysqli_connect_error($conexao);
}

mysqli_close($conexao);
?>

