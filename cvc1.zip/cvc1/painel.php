<?php
session_start();
include('PARTIALS/verifica_login.php')
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CVC - Viagens</title>
    <link rel="stylesheet" href="CSS/bootstrap.min.css">
    <link rel="stylesheet" href="CSS/style.css">
</head>

<body>

    <!-- Menu de Navegação -->
    <header
        class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom"
        style="background-color: #ffe600;">
        <a href="/" class="d-flex align-items-center col-md-3 mb-2 mb-md-0 text-dark text-decoration-none mx-3">
            <img src="IMG/cvc-logo.png" width="60" height="42" alt="Logo CVC">
        </a>

        <ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
            <li><a href="#cart" class="nav-link px-2 link-dark">
                    <font style="vertical-align: inherit;">
                        <font style="vertical-align: inherit;">Carrinho</font>
                    </font>
                </a></li>
            <li><a href="" class="nav-link px-2 link-dark">
                    <font style="vertical-align: inherit;">
                        <font style="vertical-align: inherit;">Perguntas frequentes</font>
                    </font>
                </a></li>
            <li><a href="" class="nav-link px-2 link-dark">
                    <font style="vertical-align: inherit;">
                        <font style="vertical-align: inherit;">Sobre Nós</font>
                    </font>
                </a></li>
        </ul>

        <div class="col-md-3 text-end mx-3">
            <h5>Olá <?php echo $_SESSION['login']?></h5>
            <button class = "btn btn-outline-primary"><a href = "PARTIALS/logout.php">Sair</a></button>
        </div>
    </header>

    <!-- 1º Sessão -->
    <div class="container">
        <div class="row flex-lg-row-reverse align-items-center g-5 py-5">
            <div class="col-10 col-sm-8 col-lg-6">
                <img src="IMG/cristoredentor.jpeg" class="d-block mx-lg-auto img-fluid" alt="Cristo Redentor"
                    width="700" height="500" loading="lazy">
            </div>
            <div class="col-lg-6">
                <h1 class="display-5 fw-bold lh-1 mb-3">
                    <font style="vertical-align: inherit;">
                        <font style="vertical-align: inherit;">Conheça os destinos mais desejados do Mundo!</font>
                    </font>
                </h1>
                <p class="lead">
                    <font style="vertical-align: inherit;">
                        <font style="vertical-align: inherit;">Aqui garantimos seu conforto, diversão e experiências
                            incríveis por todos os lugares!</font>
                    </font>
                </p>
            </div>
        </div>
    </div>

    <!-- 2º Sessão (Vitrine de Produtos)-->
    <div class="container text-center my-5">
        <h1 class="display-5 fw-bold lh-1 mb-5">
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Melhores Pacotes</font>
            </font>
        </h1>
        <div class="container">
            <div class="row d-flex justify-content-center" id="produtos">

            </div>
        </div>
    </div>

    <!-- 3º Sessão (Carrinho)-->
    <div class="container text-center my-5">
        <h1 class="display-5 fw-bold lh-1 mb-5" id="cart">
            <font style="vertical-align: inherit;">
                <font style="vertical-align: inherit;">Carrinho</font>
            </font>
        </h1>
        <div class="container">
            <div class="justify-content-center" id="carrinho">

            </div>
        </div>
    </div>

    <!-- 3º Sessão (Carrinho)-->
    <div class="container">
        <div class="justify-content-center" id="total">

        </div>
    </div>
    <script src="JS/bootstrap.bundle.min.js"></script>
    <script src="JS/app1.js"></script>
</body>

</html>