-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 23-Jun-2022 às 22:37
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `cvc_srv`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE `clientes` (
  `nome` varchar(140) NOT NULL,
  `email` varchar(256) NOT NULL,
  `senha` varchar(16) NOT NULL,
  `telefone` varchar(11) NOT NULL,
  `genero` varchar(20) NOT NULL,
  `dataNasc` date NOT NULL,
  `cidade` varchar(56) NOT NULL,
  `estado` varchar(56) NOT NULL,
  `endereco` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`nome`, `email`, `senha`, `telefone`, `genero`, `dataNasc`, `cidade`, `estado`, `endereco`) VALUES
('Gabriel Serpa', 'gabriel@teste.com', '123456', '85997337392', 'masculino', '2002-11-13', 'Fortaleza', 'Ceará', 'Rua Cabo Verde, 558'),
('Maria Gabriela', 'gabriela@teste.com', '123456', '89988888888', 'feminino', '2005-07-25', 'Fortaleza', 'Ceará', 'Rua Cabo Verde, 558 - Conjunto Palmeiras'),
('Savannah Líbio', 'savannah@teste.com', '123456', '85999999999', 'feminino', '1995-05-02', 'Fortaleza', 'Ceará', 'Rua Qualquer, 1985 - Aldeota'),
('Teste1', 'teste1@teste.com', '1234', '85999999999', 'outro', '2022-11-13', 'Fortaleza', 'Ceará', 'Rua X, 20 - Bairro J'),
('Teste2', 'teste2@teste.com', '1234', '85999999999', 'outro', '2022-11-13', 'Fortaleza', 'Ceará', 'Rua X, 20 - Bairro J'),
('Teste', 'teste@teste.com', '1234', '85999999999', 'outro', '2022-11-13', 'Fortaleza', 'Ceará', 'Rua X, 20 - Bairro J');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
